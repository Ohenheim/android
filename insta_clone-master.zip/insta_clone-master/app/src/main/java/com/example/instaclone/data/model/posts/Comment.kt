package com.example.instaclone.data.model.posts

data class Comment(
    val comment: String,
    val timestamp: String,
    val user_id: String,
    val username: String
)