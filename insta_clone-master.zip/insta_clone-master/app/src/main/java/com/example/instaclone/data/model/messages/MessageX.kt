package com.example.instaclone.data.model.messages

data class MessageX(
    val message: String,
    val sender_id: String,
    val timestamp: String
)