package com.example.instaclone.data.model.story

data class StoryContent(
    val timestamp: String,
    val type: String,
    val duration: Int,
    val url: String
)