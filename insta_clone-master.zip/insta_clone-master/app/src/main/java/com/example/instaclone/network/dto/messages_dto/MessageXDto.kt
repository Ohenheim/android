package com.example.instaclone.network.dto.messages_dto

data class MessageXDto(
    val message: String,
    val sender_id: String,
    val timestamp: String
)