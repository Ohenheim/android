package com.example.instaclone.pages.interfaces

interface PagerHandler {
    fun displayMediaPage()
    fun displayHomePage()
    fun displayDirectMessagesPage()
}